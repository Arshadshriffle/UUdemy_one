class Instructor < User
    has_many :courses
  end
  