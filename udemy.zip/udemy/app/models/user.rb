class User < ApplicationRecord
    has_secure_password
  
    validates :type, inclusion: { in: ["Instructor", "Student"] }
  
    def Student?
      self.type == "Student"
    end
  
    def Instructor?
      self.type == "Instructor"
    end
  end
  