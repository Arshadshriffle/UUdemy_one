class Course < ApplicationRecord
  belongs_to :instructor
  belongs_to :category

 

  validates :status, inclusion: { in: ["active", "inactive"] }
end
