class CoursesController < ApplicationController
    def create
      a = User.find(@current_user.id)
      if a.type == "Instructor"
        @course = @current_user.courses.new(course_params)
        if @course.save
          render json: @course, status: :created
        else
          render json: { errors: @course.errors.full_messages }, status: :unprocessable_entity
        end
      else
        render json: { errors: "Only Teacher Can Create Courses" }, status: :unprocessable_entity
      end
    end

    def show
      @all_courses = Course.where(instructor_id: @current_user )
      render json: @all_courses, status: :ok
    end

    # def showto
    #   @all_courses = Course.where(student_id: @current_user , status: "active")
    #   render json: @all_courses, status: :ok
    # end

    def single_course
      @single_course = Course.where(instructor_id: @current_user ).find(params[:id])
      render json: @single_course, status: :ok
    end

  

    def single_course_with_name
      @title = Course.where(instructor_id: @current_user ).where("title LIKE?" ,"%#{params[:title]}%")

      render json: @title, status: :ok
    end


    # def category_course
    #   @single_course = Course.where(student_id: @current_user ).find(params[:category_id])
    #   render json: @single_course, status: :ok
    # end

    def category_course
      @single_course = Course.where(category_id:params[:category_id])
      render json: @single_course, status: :ok
    end


    def a
      @all_courses = Course.where(instructor_id: @current_user ).find(params[:status])
      render json: @all_courses, status: :ok
    end
  
    private
  
    def course_params
      params.permit(:title, :about, :course_content, :category_id,:status)
    end
  end
  