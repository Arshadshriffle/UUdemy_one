class InstructorsController < ApplicationController
    skip_before_action :authenticate_request, only: [:create]
    before_action :set_user, only: [:show, :destroy]
  
    def create
      @instructor = Instructor.new(user_params)
      if @instructor.save
        render json: @instructor, status: :created
      else
        render json: { errors: @instructor.errors.full_messages }, status: :unprocessable_entity
      end
    end
  
    private
  
    def user_params
      params.permit(:name, :email, :password, :username, :type)
    end
  end
  