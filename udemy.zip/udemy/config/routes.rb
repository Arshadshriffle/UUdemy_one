Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  resources :instructors
  resources :students
  post "/auth/login", to: "authentication#login"
  post "/instructor/course", to: "courses#create"
  get "enrollments/show"
  post "enrollments/create"
  # get "/showto" , to: "courses/showto"
  get "/instructor/course", to: "courses#show"
  get "/instructor/single_course/:id" , to: "courses#single_course"
  get "/student/category_course/:category_id" , to: "courses#category_course"
  get "/instructor/:title" , to: "courses#single_course_with_name"
  get "/instructor/a/:status" , to: "courses#a"
end
